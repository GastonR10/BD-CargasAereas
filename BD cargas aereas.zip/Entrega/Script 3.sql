/*5. Utilizando T-SQL realizar los siguientes ejercicios: 
a. Escribir un procedimiento almacenado que reciba como par�metros un rango de fecha y 
retorne tambi�n por par�metros el identificador de avi�n que carg� m�s kilos en dicho 
rango de fechas y el nombre del cliente que carg� m�s kilos en dicho rango (si hay m�s 
de uno, mostrar el primero)*/

CREATE PROCEDURE pro_5A
@desde char(10),@hasta char(10),@IdAvionRetorno char(10) OUTPUT, @nombreClienteRetorno varchar(30) OUTPUT
AS
BEGIN
DECLARE @IdAvion char(10), @nombreCliente varchar(30)

Select TOP 1 @IdAvion = avionID from Carga
where cargaFch >= @desde and cargaFch <= @hasta
group by avionID
order by SUM(cargaKilos) desc

Select TOP 1 @nombreCliente = c.cliNom from Cliente c join Carga ca on c.cliID = ca.cliID
where cargaFch >= @desde and cargaFch <= @hasta
group by c.cliNom
order by SUM(ca.cargaKilos) desc

SET @IdAvionRetorno = @IdAvion
SET @nombreClienteRetorno = @nombreCliente

END 

/*Prueba el procedimiento almacenado 5A*/
DECLARE @IdAvionResult char(10)
DECLARE @nombreClienteResult varchar(30)

EXECUTE pro_5A '2022-04-05', '2023-05-12', @IdAvionResult OUTPUT, @nombreClienteResult OUTPUT
PRiNT @IdAvionResult 
print @nombreClienteResult

/*b. Realizar un procedimiento almacenado que, dadas las 3 medidas de un contenedor (largo 
x ancho x alto) retorne en una tabla los datos de los contenedores que coinciden con 
dichas medidas, de no existir ninguno se debe retornar un mensaje.*/	

CREATE PROCEDURE pro_5B
@Largo decimal,@Ancho decimal,@Alto decimal
AS
BEGIN
 IF EXISTS (Select * from Dcontainer
			where dcontAlto = @Alto and dContAncho = @Ancho and dContLargo = @Largo)
	BEGIN
		Select * from Dcontainer
		where dcontAlto = @Alto and dContAncho = @Ancho and dContLargo = @Largo
	END
 ELSE 
	BEGIN
		PRINT 'No hay contenedores con esas medidas. '
	END
END

--esto es una prueba
EXECUTE pro_5B 2.4, 3.2, 1.8


/*c. Hacer una funci�n que reciba un c�digo de aeropuerto y retorne la cantidad de kilos 
recibidos de carga cuando ese aeropuerto fue destino.*/

CREATE FUNCTION funcion_5C(@codAeropuerto char(3))
RETURNS decimal
AS
BEGIN
DECLARE @cantKilos decimal

SELECT @cantKilos=Sum(c.cargaKilos)
FROM Carga c 
group by c.aeroDestino
having c.aeroDestino = @codAeropuerto
                    
RETURN @cantKilos
END

--esto es una prueba
select dbo.funcion_5C('SYD')


/*d. Hacer una funci�n que, para un cliente dado, retorne la cantidad total de kilos 
transportados por dicho cliente a aeropuertos de diferente pa�s.*/

CREATE FUNCTION funcion_5D(@clienteID int)
RETURNS table
AS                  
RETURN (
 SELECT a.aeroPais as Pais,Sum(c.cargaKilos) as 'cantidad de kilos'
 FROM Carga c join Aeropuerto a on a.codIATA = c.aeroDestino
 group by a.aeroPais,cliID
 having cliID =@clienteID
)


--esto es una prueba
SELECT *
FROM dbo.funcion_5D(1)

