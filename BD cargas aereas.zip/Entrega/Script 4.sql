/*
6. Escribir los siguientes disparadores :
a. Realizar un disparador que lleve un mantenimiento de la cantidad de cargas
acumuladas de un cliente, este disparador debe controlar tanto los ingresos de cargas
como el borrado de cargas.
*/

CREATE TRIGGER trigger_6A
ON Carga
AFTER INSERT, DELETE
AS
BEGIN

 IF EXISTS (SELECT * FROM inserted)
    BEGIN
	 -- Actualizar clientes para las filas insertadas
	 UPDATE Cliente
     SET cliCantCargas = cliCantCargas + (SELECT COUNT(i.cliID)
										  FROM inserted i
										  WHERE i.cliID = Cliente.cliID)
     WHERE cliID IN (SELECT cliID FROM inserted)
	END
 ELSE
	BEGIN
     -- Actualizar clientes para las filas eliminadas
     UPDATE Cliente
     SET cliCantCargas = cliCantCargas - (SELECT COUNT(d.cliID)
										  FROM deleted d
										  WHERE d.cliID = Cliente.cliID)
     WHERE cliID IN (SELECT cliID FROM deleted)
	END
END


/*
b. Hacer un disparador que, ante la modificaci�n de cualquier medida de un contenedor,
   lleve un registro detallado en la tabla AuditContainer (ver estructura de la tabla en el
   anexo del presente obligatorio).
*/

CREATE TRIGGER trigger_6B
ON DContainer
AFTER UPDATE
AS
BEGIN
IF UPDATE(dContLargo) OR UPDATE(dContAncho) OR UPDATE(dContALto) OR UPDATE(dContCapacidad) 

INSERT INTO AuditContainer SELECT getdate(), host_name(), d.dContLargo, d.dContAncho, d.dcontAlto,
							      d.dcontCapacidad, i.dContLargo, i.dContAncho, i.dcontAlto, i.dcontCapacidad
						   FROM inserted i, deleted d
						   WHERE i.dContID = d.dContID
END


/*
c. Realizar un disparador que cuando se registra una nueva carga se valide que el avi�n
tiene capacidad suficiente para almacenarla, esta verificaci�n debe tener en cuenta
todas las cargas que se est�n haciendo en ese avi�n en la misma fecha.
*/

CREATE TRIGGER trigger_6C
ON Carga
INSTEAD OF INSERT 
AS
DECLARE 
 @AvionID char(10), 
 @cargaFch date, 
 @cargaKilos decimal,
 @aeroOrigen char(3), 
 @CapAvion decimal, 
 @CargaAvionFecha decimal
BEGIN
	SELECT @AvionID = avionID,  
		   @cargaFch = cargaFch, 
		   @cargaKilos = cargaKilos
	FROM inserted 

	SELECT @CapAvion = a.avionCapacidad
	FROM inserted i, Avion a
	WHERE i.avionID = a.avionID
	
	SELECT @CargaAvionFecha = SUM(c.cargaKilos)
	FROM Avion a, Carga c 
	WHERE a.avionID = c.avionID 
	GROUP BY c.cargaFch, c.avionID
	HAVING c.cargaFch = @cargaFch AND c.avionID = @AvionID

	IF (@CargaAvionFecha is null)
		BEGIN
			SET @CargaAvionFecha = 0
		END		

 IF (@cargaKilos + @CargaAvionFecha <= @CapAvion)	
	BEGIN
		INSERT INTO Carga 
		SELECT avionID, dContID, cargaFch, cargaKilos, cliID, aeroOrigen, aeroDestino, cargaStatus FROM inserted	
	END
 ELSE
	BEGIN
		PRINT 'Se sobrepas� la capacidad del avi�n por ' + STR(@cargaKilos + @CargaAvionFecha - @CapAvion) + ' Kg'
	END
END
