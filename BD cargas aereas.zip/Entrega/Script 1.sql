CREATE DATABASE GestionCargas
GO
USE GestionCargas
GO


/* Creacion de tablas SIN restricciones */
CREATE TABLE Cliente(cliID int identity not null,
                     cliNom varchar(30) not null,
					 cliMail varchar(50),
					 cliCantCargas int)
GO
CREATE TABLE Avion(avionID char(10) not null,
                   avionMAT varchar(20) not null,
				   avionMarca varchar(30) not null,
				   avionModelo varchar(30) not null,
				   avionCapacidad decimal)
GO
CREATE TABLE Dcontainer(dContID char(6) not null,
                       	dContLargo decimal,
						dContAncho decimal,
						dcontAlto decimal,
						dcontCapacidad decimal)
GO
CREATE TABLE Aeropuerto(codIATA char(3) not null,
                        aeroNombre varchar(30) not null,
						aeroPais varchar(30) not null)
GO
CREATE TABLE Carga(idCarga int identity not null,
                   avionID char(10) not null,
				   dContID char(6) not null,
				   cargaFch date,
				   cargaKilos decimal,
				   cliID int,
				   aeroOrigen char(3),
				   aeroDestino char(3),
				   cargaStatus char(1))
GO
CREATE TABLE AuditContainer(AuditID int identity not null,
                            AuditFecha datetime,
							AuditHost varchar(30),
                       	    LargoAnterior decimal,
						    AnchoAnterior decimal,
						    AltoAnterior decimal,
						    CapAnterior decimal,
							LargoActual decimal,
						    AnchoActual decimal,
						    AltoActual decimal,
						    CapActual decimal)
GO	


/*Condiciones Tabla Cliente*/ /*Falta el codigo auto incremental y el incremento de cargas acumuladas*/
ALTER TABLE Cliente ADD CONSTRAINT PK_Cliente PRIMARY KEY (cliID)
ALTER TABLE Cliente ADD CONSTRAINT UK_cliMail UNIQUE (cliMail)


/*Condiciones Tabla Avion*/
ALTER TABLE Avion ADD CONSTRAINT PK_Avion PRIMARY KEY (avionID)
ALTER TABLE Avion ADD CONSTRAINT CK_CapacidadAvion CHECK (avionCapacidad <= 150000)

/*Condiciones Tabla Dcontainer*/ /*CONTROLAR TRES LETRAS Y TRES NUMEROS*/
ALTER TABLE Dcontainer ADD CONSTRAINT PK_Dcontainer PRIMARY KEY (dContID)
ALTER TABLE Dcontainer ADD CONSTRAINT CK_LargoMax CHECK (dContLargo <= 2.5)
ALTER TABLE Dcontainer ADD CONSTRAINT CK_AnchoMax CHECK (dContAncho <= 3.5)
ALTER TABLE Dcontainer ADD CONSTRAINT CK_AltoMax CHECK (dContAlto <= 2.5)
ALTER TABLE Dcontainer ADD CONSTRAINT CK_CapacidadMax CHECK (dContCapacidad <= 7)

/*Condiciones Tabla Aeropuerto*/
ALTER TABLE Aeropuerto ADD CONSTRAINT PK_Aeropuerto PRIMARY KEY (codIATA)

/*Condiciones Tabla Carga*/ /*Falta el codigo auto incremental -- ��char(1)??*/
ALTER TABLE Carga ADD CONSTRAINT PK_Carga PRIMARY KEY (idCarga)
ALTER TABLE Carga ADD CONSTRAINT FK_Avion FOREIGN KEY (avionID) REFERENCES Avion(avionID)
ALTER TABLE Carga ADD CONSTRAINT FK_Dcontainer FOREIGN KEY (dContID) REFERENCES Dcontainer(dContID)
ALTER TABLE Carga ADD CONSTRAINT FK_Cliente FOREIGN KEY (cliID) REFERENCES Cliente(cliID)
ALTER TABLE Carga ADD CONSTRAINT FK_AeropOrigen FOREIGN KEY (aeroOrigen) REFERENCES Aeropuerto(codIATA)
ALTER TABLE Carga ADD CONSTRAINT FK_AeropDestino FOREIGN KEY (aeroDestino) REFERENCES Aeropuerto(codIATA)
ALTER TABLE Carga ADD CONSTRAINT CK_CargaStatus CHECK (cargaStatus IN ('R', 'C', 'T', 'D', 'E'))
ALTER TABLE Carga ADD CONSTRAINT UK_Carga UNIQUE (avionID, dContID, cargaFch)

/*Creaci�n de �ndices*/
CREATE INDEX IDX_IdAvionCarga ON Carga(avionID)
CREATE INDEX IDX_DcontainerCarga ON Carga(dContID)
CREATE INDEX IDX_ClienteCarga ON Carga(cliID)
CREATE INDEX IDX_AeropOrigenCarga ON Carga(aeroOrigen)
CREATE INDEX IDX_AeropDestinoCarga ON Carga(aeroDestino)




INSERT INTO Cliente VALUES ('Angel','angel@mail.com',0)
INSERT INTO Cliente VALUES ('Angela','angela@mail.com',0)
INSERT INTO Cliente VALUES ('Lionel','leo@mail.com',0)
INSERT INTO Cliente VALUES ('Thiago','thiago@mail.com',0)
INSERT INTO Cliente VALUES ('Peter','peter@mail.com',0)


--Avion(avionID,avionMAT,avionMarca,avionModelo,avionCapacidad)


INSERT INTO Avion (avionID, avionMAT, avionMarca, avionModelo, avionCapacidad) VALUES ('AV001-2022', 'EDM989', 'Boeing', '747-8F', 140000), 
																					  ('AV002-2022', 'MNY234', 'Airbus', 'A330-200F', 70500), 
																					  ('AV003-2022', 'KLM789', 'Antonov', 'An-124', 150000), 
																					  ('AV004-2022', 'HAY387', 'Boeing', '777F', 110800), 
																					  ('AV005-2022', 'FRG432', 'Airbus', 'A300-600F', 54000), 
																					  ('AV006-2022', 'QWE769', 'Embraer', 'E195-E2', 41400), 
																					  ('AV007-2022', 'BHA234', 'Boeing', '787-9F', 120500), 
																					  ('AV008-2022', 'LYG567', 'Lockheed Martin', 'C-5M Super Galaxy', 122500), 
																					  ('AV009-2022', 'GJS234', 'Airbus', 'A380F', 150000), 
																					  ('AV010-2022', 'HJP432', 'Boeing', '747-400ERF', 126800)

																					  

INSERT INTO DContainer (dContID, dContLargo, dContAncho, dContAlto, dContCapacidad) VALUES ('ABC123', 2.4, 3.2, 1.8, 5.5), 
																						   ('DEF456', 1.8, 2.7, 1.2, 2.2), 
																						   ('GHI789', 2.1, 3.1, 2.2, 6.8), 
																						   ('JKL012', 2.3, 3.3, 2.4, 7.0), 
																						   ('MNO345', 2.2, 3.0, 2.1, 6.2),
																						   ('PQR678', 1.9, 2.5, 1.5, 3.7), 
																						   ('STU901', 2.0, 3.0, 2.0, 5.3), 
																						   ('VWX234', 2.4, 3.4, 2.4, 6.9), 
																						   ('YZA567', 1.5, 2.0, 1.5, 1.9), 
																						   ('BCD890', 2.4, 3.4, 2.1, 5.9);


INSERT INTO Aeropuerto (codIATA, aeroNombre, aeroPais) VALUES ('MEX', 'Aeropuerto Ciudad de M�xico', 'M�xico'), 
															  ('LAX', 'Aeropuerto Los �ngeles', 'Estados Unidos'), 
															  ('JFK', 'Aeropuerto John F. Kennedy', 'Estados Unidos'), 
															  ('BCN', 'Aeropuerto Barcelona-El Prat', 'Espa�a'), 
															  ('CDG', 'Aeropuerto PSG', 'Francia'), 
															  ('HND', 'Aeropuerto Haneda', 'Jap�n'), 
															  ('SYD', 'Aeropuerto S�dney', 'Australia'), 
															  ('PEK', 'Aeropuerto Pek�n', 'China'), 
															  ('DXB', 'Aeropuerto Dub�i', 'Emiratos �rabes Unidos'), 
															  ('LHR', 'Aeropuerto Londres-Heathrow', 'Reino Unido');

INSERT INTO Carga (avionID, dContID, cargaFch, cargaKilos, cliID, aeroOrigen, aeroDestino, cargaStatus) 
VALUES ('AV001-2022', 'MNO345', '2022-01-15', 5000, 1, 'MEX', 'LAX', 'R'), 
	   ('AV002-2022', 'GHI789', '2022-02-10', 3500.50, 2, 'CDG', 'JFK', 'C'), 
	   ('AV010-2022', 'ABC123', '2022-03-20', 6000.00, 3, 'PEK', 'LHR', 'T'), 
	   ('AV009-2022', 'PQR678', '2022-04-05', 2500.00, 1, 'MEX', 'HND', 'D'), 
	   ('AV007-2022', 'GHI789', '2022-05-12', 4500.75, 2, 'SYD', 'DXB', 'E'),
	   ('AV008-2022','GHI789', '2023-03-03', 4000.00, 4, 'CDG', 'HND', 'R'),
	   ('AV001-2022', 'MNO345', '2023-01-15', 3000.00, 1, 'MEX', 'LAX', 'R'), 
	   ('AV002-2022', 'GHI789', '2023-02-10', 4500.50, 2, 'CDG', 'JFK', 'C'), 
	   ('AV010-2022', 'ABC123', '2023-03-20', 8000.00, 3, 'PEK', 'LHR', 'T'), 
	   ('AV009-2022', 'PQR678', '2023-04-05', 9500.00, 1, 'MEX', 'HND', 'D'), 
	   ('AV007-2022', 'GHI789', '2023-05-12', 2500.75, 2, 'SYD', 'DXB', 'E'),
	   ('AV002-2022', 'MNO345', '2023-01-15', 1000.00, 1, 'SYD', 'DXB', 'R'), 
	   ('AV003-2022', 'GHI789', '2022-01-15', 2000.00, 1, 'MEX', 'LAX', 'T'),
	   ('AV004-2022', 'YZA567', '2023-01-15', 3000.00, 1, 'MEX', 'HND', 'C'), 
	   ('AV005-2022', 'MNO345', '2022-01-15', 5000.00, 1, 'PEK', 'LHR', 'E'), 
	   ('AV006-2022', 'BCD890', '2022-01-15', 4000.00, 1, 'PEK', 'LHR', 'D'), 
	   ('AV007-2022', 'BCD890', '2023-01-15', 6500.00, 1, 'CDG', 'JFK', 'R'), 
	   ('AV008-2022', 'PQR678', '2022-01-15', 1700.00, 1, 'MEX', 'HND', 'T'),
	   ('AV005-2022', 'MNO345', '2010-01-15', 5000, 3, 'SYD', 'CDG', 'R'),
	   ('AV007-2022', 'PQR678', '2011-02-20', 5000, 5, 'LAX', 'HND', 'D'),
	   ('AV009-2022', 'VWX234', '2015-05-21', 5000, 4, 'MEX', 'CDG', 'T'),
	   ('AV010-2022', 'BCD890', '2016-08-30', 5000, 4, 'CDG', 'LAX', 'C'),
	   ('AV001-2022', 'MNO345', '2023-06-03', 333, 5, 'MEX', 'LAX', 'R'),
	   ('AV010-2022', 'ABC123', '2001-03-20', 6000.00, 3, 'PEK', 'LHR', 'T'),
	   ('AV010-2022', 'ABC123', '2012-03-20', 60000.00, 3, 'PEK', 'SYD', 'T'),
	   ('AV010-2022', 'VWX234', '2022-01-15', 3800.00, 1, 'MEX', 'LAX', 'R');